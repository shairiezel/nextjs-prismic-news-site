// tailwind.config.js
module.exports = {
  purge: false,
  theme: {},
  variants: {
    borderColor: ["hover", "focus"],
  },
  plugins: [],
};
